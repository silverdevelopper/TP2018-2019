#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "patient.h"

int main(int argc, const char *argv[])
{

    srand(time(NULL));
    struct patientInfo *queue;
    queue= malloc(sizeof(struct patientInfo));
    int i;
    
    for (i = 0; i < 10; i++) {
        int ssn = (rand() % 1001) + 1000;
        int sickness = (rand() % MAX_PRIO);
        
       
        queue = enqueue(queue, sickness, ssn);
        print_queue(queue);

       
       
    }

    return 0;
}
