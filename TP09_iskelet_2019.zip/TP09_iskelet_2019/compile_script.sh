gcc -c strassen.c -o strassen.o
gcc main.c strassen.o -o main 

